---
name: tar-hook
description: tar-hook
metadata: {"kova":{"events":["command:new"]}}
---

# Hook