---
name: one-hook
description: One hook
metadata: {"kova":{"events":["command:new"]}}
---

# One Hook