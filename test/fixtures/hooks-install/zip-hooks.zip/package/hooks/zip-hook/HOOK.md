---
name: zip-hook
description: Zip hook
metadata: {"kova":{"events":["command:new"]}}
---

# Zip Hook