---
name: reserved-hook
description: reserved-hook
metadata: {"kova":{"events":["command:new"]}}
---

# Hook