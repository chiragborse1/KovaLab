---
name: evil-hook
description: evil-hook
metadata: {"kova":{"events":["command:new"]}}
---

# Hook